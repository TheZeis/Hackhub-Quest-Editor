# Twotter Q&A Test

Testing Twotter post node

## Install (no coding needed)

1. Copy this whole folder into the game's `mods/` directory.
2. Start HackHub — the mod loads from `dist/mod.js`.

## Rebuild (optional, for programmers)

`src/index.ts` is the same code as `dist/mod.js`. With Node 18+:

```
npm install
npm run build
```

## What the editor compiled for you

- Quests: TwotterQA
- Websites: none
- Permissions requested: mail

## Notes

- Everything compiled cleanly. Have fun.
